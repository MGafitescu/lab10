CREATE type body jurnal as
member procedure afiseaza_an is
begin 
DBMS_OUTPUT.PUT_LINE('anul este'||an_aparitie);
end afiseaza_an;
constructor function jurnal (titlu varchar2, autor varchar2) return self as result
as
begin
self.titlu:=titlu;
self.autor:=autor;
self.an_aparitie:=20;
return;
end;
end;

/

