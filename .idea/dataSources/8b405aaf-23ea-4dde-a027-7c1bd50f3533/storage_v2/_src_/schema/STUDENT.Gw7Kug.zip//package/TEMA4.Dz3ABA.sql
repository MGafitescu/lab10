CREATE PACKAGE tema4 IS
    TYPE modificari IS RECORD(v_id studenti.id%type, v_procent NUMBER);
    TYPE lista IS VARRAY(10) OF modificari;
    PROCEDURE modifica_bursa(v_lista IN lista);
    --ALTER TABLE studenti ADD istoric istoric_bursa NESTED TABLE istoric STORE AS istorie_bursa;
    PROCEDURE afiseaza_modificari;
END tema4;
/

