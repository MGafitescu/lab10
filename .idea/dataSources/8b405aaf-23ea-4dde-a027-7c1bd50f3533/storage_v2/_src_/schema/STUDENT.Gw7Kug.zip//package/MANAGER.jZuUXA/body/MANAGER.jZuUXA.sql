CREATE PACKAGE BODY manager IS

    PROCEDURE calculeaza_varsta (p_data_nastere IN DATE, p_ani OUT NUMBER, p_luni OUT NUMBER, p_zile OUT NUMBER) as
    BEGIN
    SELECT TRUNC(MONTHS_BETWEEN(SYSDATE,TO_DATE(p_data_nastere,'DD-MM-YYYY'))) INTO p_luni FROM dual;
    p_ani := trunc(p_luni/12);
    IF ( extract(month from sysdate)> extract(month from p_data_nastere))
    then
    p_ani := p_ani-1;
    else
        if ( extract(month from sysdate)  = extract(month from p_data_nastere) and  extract(day from sysdate)> extract(day from p_data_nastere))
        then
        p_ani := p_ani-1;
        end if;
    end if;    
    p_zile := trunc(sysdate- add_months(p_data_nastere,p_luni));
    p_luni := trunc(p_luni mod 12);  
    END calculeaza_varsta;   

    PROCEDURE adauga_student (p_nume varchar, p_prenume varchar) is
    v_id_rand NUMBER := DBMS_RANDOM.VALUE('100','999');
v_id_ok NUMBER :=0;
v_nr_id NUMBER := 0;
v_nr1_matricol NUMBER := DBMS_RANDOM.VALUE('100','999');
v_nr2_matricol NUMBER :=DBMS_RANDOM.VALUE('0','9');
v_litere_matricol VARCHAR(2) := DBMS_RANDOM.string('U',2);
v_matricol_rand studenti.nr_matricol%type;
BEGIN 

WHILE(v_id_ok =0) LOOP
    SELECT count(*) INTO v_nr_id from (select id from studenti where id=v_id_rand);
    IF(v_nr_id = 0) then v_id_ok :=1;
    end if;
end loop;

v_matricol_rand :=v_nr1_matricol||v_litere_matricol||v_nr2_matricol;

INSERT INTO studenti(id,nr_matricol,nume,prenume) VALUES (v_id_rand,v_matricol_rand,p_nume,p_prenume);

    END adauga_student;

    PROCEDURE sterge_student (p_nr_matricol studenti.nr_matricol%type) IS
    v_id studenti.id%type;
    BEGIN
    SELECT id into v_id from studenti where studenti.nr_matricol like p_nr_matricol;
    DELETE FROM note where note.id_student=v_id;
    DELETE FROM prieteni where prieteni.id_student1=v_id or prieteni.id_student2=v_id;
    DELETE FROM studenti where studenti.id=v_id;
    DBMS_OUTPUT.PUT_LINE(chr(10)||'Studentul cu numarul matricol ' || p_nr_matricol ||' sters cu succes');
    END sterge_student;

    PROCEDURE afiseaza_student (p_nume varchar, p_prenume varchar) 
    IS 
    p_ani NUMBER;
    p_luni NUMBER;
    p_zile NUMBER;
    p_data_nastere studenti.data_nastere%type;
    v_id studenti.id%type;
    v_medie number;
    v_nr_matricol studenti.nr_matricol%type;
    v_pozitie NUMBER;
    CURSOR lista_prieteni(p_id studenti.id%type) IS 
    SELECT nume, prenume from studenti join prieteni on studenti.id=prieteni.id_student2 where id_student1=p_id;
    CURSOR lista_note(p_id studenti.id%type) IS 
    SELECT cursuri.titlu_curs, valoare from note join cursuri on note.id_curs=cursuri.id where note.id_student=p_id;

    BEGIN
          select studenti.id, studenti.nr_matricol into v_id, v_nr_matricol from studenti where studenti.nume like p_nume and studenti.prenume like p_prenume;
          select data_nastere into p_data_nastere from studenti where studenti.id = v_id;

          calculeaza_varsta(p_data_nastere,p_ani,p_luni,p_zile);

          select avg(valoare) into v_medie from note group by id_student having id_student=v_id;

          select count(*) into v_pozitie from( select studenti.id as "ID",avg(valoare) from studenti join note on note.id_student=studenti.id
          where studenti.grupa=(select grupa from studenti where studenti.id=189) 
          group by studenti.id having avg(valoare)>v_medie );

          DBMS_OUTPUT.PUT_LINE(p_nume ||' '||p_prenume);
          DBMS_OUTPUT.PUT_LINE(chr(10)||'Id : ' || v_id || ' Numar matricol: ' || v_nr_matricol);
          DBMS_OUTPUT.PUT_LINE(chr(10)||'Media: ' || v_medie);
          DBMS_OUTPUT.PUT_LINE('Pozitia in grupa: '||v_pozitie);
          DBMS_OUTPUT.PUT_LINE(chr(10)||'Varsta studentului: ' ||p_ani || ' ani , ' ||  p_luni  ||' luni si '|| p_zile || ' zile ' );
          DBMS_OUTPUT.PUT_LINE(chr(10)||'Notele studentului: ');
          FOR v_linie IN lista_note(v_id) LOOP
            DBMS_OUTPUT.PUT_LINE(v_linie.titlu_curs||' - '||v_linie.valoare );
          END LOOP;
          DBMS_OUTPUT.PUT_LINE(chr(10)||'Prietenii studentului: ');
          FOR v_linie IN lista_prieteni(v_id) LOOP
            DBMS_OUTPUT.PUT_LINE(v_linie.nume ||' '||v_linie.prenume );
          END LOOP;

    END afiseaza_student;
END manager;
/

