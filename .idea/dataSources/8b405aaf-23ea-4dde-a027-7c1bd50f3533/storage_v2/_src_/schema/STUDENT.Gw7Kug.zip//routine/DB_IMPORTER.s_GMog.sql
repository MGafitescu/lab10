CREATE PROCEDURE db_importer
AS
  v_fisier_studenti UTL_FILE.FILE_TYPE;
  v_fisier_prieteni UTL_FILE.FILE_TYPE;
  v_sir_studenti VARCHAR2(150);
  v_sir_prieteni VARCHAR2(150);
  v_id studenti.id%type;
  v_nr_matricol studenti.nr_matricol%type;
  v_nume studenti.nume%type;
  v_prenume studenti.prenume%type;
  v_an studenti.an%type;
  v_grupa studenti.grupa%type;
  v_bursa studenti.bursa%type;
  v_data_nastere studenti.data_nastere%type;
  v_email studenti.email%type;
  v_created_at studenti.created_at%type;
  v_updated_at studenti.updated_at%type;
  v_idp prieteni.id%type;
  v_id1 prieteni.id_student1%type;
  v_id2 prieteni.id_student2%type;
  v_created prieteni.created_at%type;
  v_updated prieteni.updated_at%type;
  student_inexistent EXCEPTION;
  v_numar number;
  PRAGMA EXCEPTION_INIT(student_inexistent, -20001);
BEGIN
  v_fisier_studenti:=UTL_FILE.FOPEN('MYDIR','lista_studenti.txt','R');
  v_fisier_prieteni:=UTL_FILE.FOPEN('MYDIR','lista_prieteni.txt','R');
  LOOP
  begin
       UTL_FILE.GET_LINE(v_fisier_studenti,v_sir_studenti);
       v_id := to_number(substr(v_sir_studenti,1,INSTR(v_sir_studenti, ',', 1, 1)-1));
       v_nr_matricol := substr(v_sir_studenti,INSTR(v_sir_studenti, ',', 1, 1)+1,INSTR(v_sir_studenti, ',', 1, 2)-INSTR(v_sir_studenti, ',', 1, 1)-1);
       v_nume := substr(v_sir_studenti,INSTR(v_sir_studenti, ',', 1, 2)+1,INSTR(v_sir_studenti, ',', 1, 3)-INSTR(v_sir_studenti, ',', 1, 2)-1);
       v_prenume := substr(v_sir_studenti,INSTR(v_sir_studenti, ',', 1, 3)+1,INSTR(v_sir_studenti, ',', 1, 4)-INSTR(v_sir_studenti, ',', 1, 3)-1);
       v_an := to_number(substr(v_sir_studenti,INSTR(v_sir_studenti, ',', 1, 4)+1,INSTR(v_sir_studenti, ',', 1, 5)-INSTR(v_sir_studenti, ',', 1, 4)-1));
       v_grupa := substr(v_sir_studenti,INSTR(v_sir_studenti, ',', 1, 5)+1,INSTR(v_sir_studenti, ',', 1, 6)-INSTR(v_sir_studenti, ',', 1, 5)-1);
       v_bursa := to_number(substr(v_sir_studenti,INSTR(v_sir_studenti, ',', 1, 6)+1,INSTR(v_sir_studenti, ',', 1, 7)-INSTR(v_sir_studenti, ',', 1, 6)-1));
       v_data_nastere := to_date((substr(v_sir_studenti,INSTR(v_sir_studenti, ',', 1, 7)+1,INSTR(v_sir_studenti, ',', 1, 8)-INSTR(v_sir_studenti, ',', 1, 7)-1)),'DD-MON-YY');
       v_email := substr(v_sir_studenti,INSTR(v_sir_studenti, ',', 1, 8)+1,INSTR(v_sir_studenti, ',', 1, 9)-INSTR(v_sir_studenti, ',', 1, 8)-1);
       v_created_at := to_date((substr(v_sir_studenti,INSTR(v_sir_studenti, ',', 1, 9)+1,INSTR(v_sir_studenti, ',', 1, 10)-INSTR(v_sir_studenti, ',', 1, 9)-1)),'DD-MON-YY');
       v_updated_at := to_date((substr(v_sir_studenti,INSTR(v_sir_studenti, ',', 1, 10)+1,INSTR(v_sir_studenti, ',', 1, 11)-INSTR(v_sir_studenti, ',', 1, 10)-1)),'DD-MON-YY');
       insert into studenti values (v_id,v_nr_matricol,v_nume,v_prenume,v_an,v_grupa,v_bursa,v_data_nastere,v_email,v_created_at,v_updated_at);

       EXCEPTION
        WHEN no_data_found THEN
        exit;
        WHEN DUP_VAL_ON_INDEX THEN
        dbms_output.put_line('Studentul cu id '||v_id||' exista');
    end;
   END LOOP;
          Dbms_output.put_line('Insertion done');
    LOOP
  begin
       UTL_FILE.GET_LINE(v_fisier_prieteni,v_sir_prieteni);
       v_idp := to_number(substr(v_sir_prieteni,1,INSTR(v_sir_prieteni, ',', 1, 1)-1));
       v_id1 := to_number(substr(v_sir_prieteni,INSTR(v_sir_prieteni, ',', 1, 1)+1,INSTR(v_sir_prieteni, ',', 1, 2)-INSTR(v_sir_prieteni, ',', 1, 1)-1));
       v_id2 := to_number(substr(v_sir_prieteni,INSTR(v_sir_prieteni, ',', 1, 2)+1,INSTR(v_sir_prieteni, ',', 1, 3)-INSTR(v_sir_prieteni, ',', 1, 2)-1));
       v_created:= to_date((substr(v_sir_prieteni,INSTR(v_sir_prieteni, ',', 1, 3)+1,INSTR(v_sir_prieteni, ',', 1, 4)-INSTR(v_sir_prieteni, ',', 1, 3)-1)),'DD-MON-YY');
       v_updated := to_date((substr(v_sir_prieteni,INSTR(v_sir_prieteni, ',', 1, 4)+1,INSTR(v_sir_prieteni, ',', 1, 5)-INSTR(v_sir_prieteni, ',', 1, 4)-1)),'DD-MON-YY');
      select count(*) into v_numar from studenti where id = v_id1 or id=v_id2;
      if (v_numar !=2 ) then
      raise student_inexistent;
      end if;
       insert into prieteni values (v_idp,v_id1,v_id2,v_created,v_updated);
       EXCEPTION
        WHEN no_data_found THEN
        exit;
        WHEN DUP_VAL_ON_INDEX THEN
        dbms_output.put_line('Prietenia cu id '||v_id||' exista');
        WHEN student_inexistent THEN
        dbms_output.put_line('Un student din cei referentiati :'||v_id1||', '||v_id2||' nu exista');
    end;
   END LOOP;
          Dbms_output.put_line('Insertion done');

UTL_FILE.FCLOSE(v_fisier_prieteni);
END;
/

