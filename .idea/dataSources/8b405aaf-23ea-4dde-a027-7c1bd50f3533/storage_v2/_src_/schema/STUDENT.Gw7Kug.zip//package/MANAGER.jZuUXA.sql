CREATE PACKAGE manager IS
     PROCEDURE adauga_student (p_nume varchar, p_prenume varchar);
     PROCEDURE sterge_student (p_nr_matricol studenti.nr_matricol%type);
     PROCEDURE afiseaza_student (p_nume varchar, p_prenume varchar);
END manager;
/

