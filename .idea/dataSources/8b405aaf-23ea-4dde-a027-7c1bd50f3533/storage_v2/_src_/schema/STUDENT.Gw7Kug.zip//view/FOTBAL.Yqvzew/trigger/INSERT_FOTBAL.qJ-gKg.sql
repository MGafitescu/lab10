-- Cannot generate trigger INSERT_FOTBAL: the table is unknown
/

