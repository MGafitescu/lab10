CREATE TYPE dreptunghi UNDER forma
(    
   latime NUMBER,
   lungime NUMBER,
   OVERRIDING member procedure afiseaza_tip,
   member procedure seteaza_suprafata(latime number, lungime number)
)
/

