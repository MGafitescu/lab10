CREATE VIEW BEST AS
  select nume, bursa from studenti where bursa>1350 with check option
/

