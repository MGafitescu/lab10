CREATE VIEW FOTBAL AS
  select "ID","NUME","PRENUME","VARSTA","ID_ECHIPA","NUME_ECHIPA","ID_ANTRENOR","POZITIE","PUNCTE" from antrenori full outer join echipe on antrenori.id=echipe.id_antrenor
/

