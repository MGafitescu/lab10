CREATE PROCEDURE db_exporter 
AS
  v_fisier_studenti UTL_FILE.FILE_TYPE;
  v_fisier_prieteni UTL_FILE.FILE_TYPE;
  CURSOR lista_studenti  IS
       SELECT * FROM studenti;
  CURSOR lista_prieteni IS
       SELECT * FROM prieteni;     
BEGIN
  v_fisier_studenti:=UTL_FILE.FOPEN('MYDIR','lista_studenti.txt','W');
  v_fisier_prieteni:=UTL_FILE.FOPEN('MYDIR','lista_prieteni.txt','W');

  FOR v_linie IN lista_studenti LOOP     
        UTL_FILE.PUT_LINE(v_fisier_studenti,v_linie.id||','||v_linie.nr_matricol||','||v_linie.nume||','||v_linie.prenume||','||v_linie.an||','||v_linie.grupa||','||v_linie.bursa||','||v_linie.data_nastere||','||v_linie.email||','||v_linie.created_at||','||v_linie.updated_at);
    END LOOP;  

 FOR v_linie IN lista_prieteni LOOP     
        UTL_FILE.PUT_LINE(v_fisier_prieteni,v_linie.id||','||v_linie.id_student1||','||v_linie.id_student2||','||v_linie.created_at||','||v_linie.updated_at);
    END LOOP;  
  UTL_FILE.FCLOSE(v_fisier_studenti);
  UTL_FILE.FCLOSE(v_fisier_prieteni);

  dbms_output.put_line('Export done');
END;
/

