CREATE TYPE istoric_bursa IS TABLE OF NUMBER(6,2);
/

