CREATE PACKAGE BODY manager_facultate IS


     PROCEDURE varsta_student (p_data_nastere DATE,p_zile OUT NUMBER,p_luni OUT NUMBER,p_ani OUT NUMBER) AS
    
      v_zi_data NUMBER;
      v_zi_azi NUMBER;
      v_zile_luna NUMBER ;
      v_anul_curent NUMBER;
      v_ok NUMBER := 0;
      v_zi NUMBER;

  BEGIN
    Select trunc(MONTHS_BETWEEN(sysdate, TO_DATE(p_data_nastere,'dd-mm-yyyy') )) into p_luni FROM DUAL;
    SELECT extract(day from to_date(p_data_nastere,'dd-mm-yyyy')) into v_zi_data from DUAL;
    SELECT extract(day from sysdate) into v_zi_azi from DUAL;

     IF v_zi_azi >= v_zi_data
        THEN p_zile := v_zi_azi-v_zi_data;
        ELSE 
           SELECT sysdate - add_months(to_date(p_data_nastere,'dd-mm-yyyy'),p_luni) into p_zile from dual;
    END IF;
    p_ani := trunc(p_luni/12);
    p_luni := p_luni - (p_ani * 12);
END varsta_student;   

PROCEDURE informatii_student (numar_matricol studenti.nr_matricol%type) AS

v_suma NUMBER :=0;
v_nr NUMBER :=0;
v_medie NUMBER;
v_luni NUMBER;
v_ani NUMBER;
v_zile NUMBER;

  BEGIN
    FOR v_linie IN tabel_studenti(numar_matricol) LOOP
           DBMS_OUTPUT.PUT_LINE('Datele studentului sunt: ');
           DBMS_OUTPUT.PUT_LINE('- numarul matricol este: ' || v_linie_stud.nr_matricol);
           DBMS_OUTPUT.PUT_LINE('-fisa matricola:');
           FOR v_linie_note IN fisa_matricola(v_linie.id) LOOP
                DBMS_OUTPUT.PUT_LINE('    -nota ' || v_linie_note.valoare || ' la materia ' || v_linie_note.titlu_curs);
                v_suma := v_suma + v_linie_note.valoare;
                v_nr := v_nr +1;
                END LOOP;

          v_medie := v_suma / v_nr;
          DBMS_OUTPUT.PUT_LINE('- media:'|| v_medie);

          varsta_student(p_data_nastere=>v_linie.data_nastere , p_luni => v_luni, p_ani => v_ani, p_zile => v_zile);
          DBMS_OUTPUT.PUT_LINE('- varsta: ' || v_linie.nume ||' '|| v_linie.prenume ||' ' || v_ani ||' ' || v_zile);

          FOR v_linie_prieten IN prieteni_studenti(v_linie_stud.id) LOOP
              DBMS_OUTPUT.PUT_LINE('Prieten: '|| v_linie_prieten.nume ||' ' || v_linie_prieten.prenume);
          END LOOP;
   END LOOP;       
  END informatii_student;


PROCEDURE stergere_student ( p_id_student studenti.id%type) IS

BEGIN
    DELETE FROM studenti WHERE  id=p_id_student;
    DELETE FROM prieteni WHERE (id_student1=p_id_student or id_student2=p_id_student);
    DELETE FROM note WHERE id_student=p_id_student;
END stergere_student;


END manager_facultate;
/

