CREATE PROCEDURE majoreaza (p_id studenti.id%type)
AS
v_bursa studenti.bursa%type;
v_istoric studenti.istoric%type;
v_dep NUMBER;
depasire EXCEPTION ;
PRAGMA EXCEPTION_INIT(depasire, -20004);
BEGIN
select bursa,istoric into v_bursa,v_istoric from studenti where id=p_id;
 if v_bursa is null
then 
v_bursa :=0;
end if;
if v_istoric.exists(1) 
then
v_istoric.extend(1);
v_istoric(v_istoric.count) := V_BURSA;
else
v_istoric := istoric_bursa(v_bursa);
end if;
v_bursa := v_bursa + 777;
V_DEP := 0;
IF v_bursa > 3000  THEN
    v_bursa  := 3000;
    v_dep := 1;
END IF;
UPDATE studenti set bursa=v_bursa where id=p_id;
UPDATE studenti set istoric=v_istoric where id=p_id;
IF v_dep = 1 then
 raise depasire;
end if;
END;
/

