-- Cannot generate trigger UPDATE_FOTBAL: the table is unknown
/

