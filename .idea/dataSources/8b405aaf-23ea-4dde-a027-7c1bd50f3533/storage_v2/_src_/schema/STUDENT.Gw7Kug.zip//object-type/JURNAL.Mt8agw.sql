CREATE type jurnal as object
(
titlu varchar2(10),
autor varchar2(10),
an_aparitie integer,
member procedure afiseaza_an,
constructor function jurnal (titlu varchar2, autor varchar2) return self as result
);
/

