CREATE VIEW TABELE AS
  select    
s.nume "Snume", s.prenume "Sprenume",s.id as "SID", p.nume "Pnume", p.prenume "Pprenume",p.id "PID",c.titlu_curs, c.id "CID",
n.id "NID", d.id"DID" 
from 
studenti s join note n on s.id=n.id_student 
join cursuri c on c.id =n.id_curs 
join didactic d on c.id=d.id_curs
join profesori p on p.id=d.id_profesor
/

