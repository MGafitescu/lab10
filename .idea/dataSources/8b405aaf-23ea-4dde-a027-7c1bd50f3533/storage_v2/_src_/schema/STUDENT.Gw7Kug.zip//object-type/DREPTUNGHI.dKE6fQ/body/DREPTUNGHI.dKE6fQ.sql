CREATE TYPE BODY dreptunghi AS
    OVERRIDING MEMBER PROCEDURE afiseaza_tip IS
    tip varchar2(10);
    BEGIN
       tip := 'Dreptunghi';
       DBMS_OUTPUT.PUT_LINE('Tip: '||tip);
    END afiseaza_tip;

    member procedure seteaza_suprafata(latime number, lungime number)is
    begin
    self.latime := latime;
    self.lungime := lungime;
    self.suprafata := lungime * latime;
    end seteaza_suprafata;

END;
/

