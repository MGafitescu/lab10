CREATE PACKAGE BODY tema4 IS

    PROCEDURE modifica_bursa(v_lista IN lista) as
      v_bursa studenti.bursa%type;
      v_procent NUMBER(4,2);
      v_id studenti.id%type;
      v_istoric studenti.istoric%type;
     BEGIN
     FOR i IN v_lista.FIRST..v_lista.LAST LOOP
     IF v_lista.exists(i) 
     THEN
        v_id := v_lista(i).v_id;
        v_procent := v_lista(i).v_procent;
        select bursa,istoric into v_bursa,v_istoric from studenti where id=v_id;
        if v_bursa is null
        then 
        v_bursa :=0;
        end if;
        if v_istoric.exists(1) 
        then
        v_istoric.extend(1);
        v_istoric(v_istoric.count) := V_BURSA;
        else
        v_istoric := istoric_bursa(v_bursa);
        end if;

        IF v_bursa = 0
        THEN
        v_bursa := 100;
        END IF;
        v_procent := v_procent/100;
        v_bursa := v_bursa + v_bursa*v_procent;
        UPDATE studenti set bursa=v_bursa where id=v_id;
        UPDATE studenti set istoric=v_istoric where id=v_id;
     END IF;
     END LOOP;
     DBMS_OUTPUT.PUT_LINE('Update facut cu succes.');
     END modifica_bursa;

     PROCEDURE afiseaza_modificari as
     CURSOR modificari IS
     SELECT * from studenti where istoric is not null;
     BEGIN
     FOR v_linie in modificari LOOP
     dbms_output.put_line('Lista cu modificari pentru studentul '||v_linie.nume||' '||v_linie.prenume||': ');
       for i in v_linie.istoric.first..v_linie.istoric.last loop
        if v_linie.istoric.exists(i) then 
           DBMS_OUTPUT.PUT(v_linie.istoric(i)||'  ');  
        end if;
    end loop; 
    Dbms_output.put_line(' ');
     END LOOP;
     END afiseaza_modificari;

END tema4;
/

