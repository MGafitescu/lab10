CREATE TYPE BODY forma AS
   
   not final member procedure afiseaza_tip is
   begin 
   dbms_output.put_line('Tip: nedeclarat');
   end afiseaza_tip;

   MEMBER PROCEDURE afiseaza_nume IS
   BEGIN
       DBMS_OUTPUT.PUT_line('Forma: '||self.nume);
   END afiseaza_nume;

    MEMBER PROCEDURE afiseaza_culoare IS
   BEGIN
       DBMS_OUTPUT.PUT_line('Culoare: '||self.culoare);
   END afiseaza_culoare;

    MEMBER PROCEDURE afiseaza_pozitie IS
   BEGIN
       DBMS_OUTPUT.PUT_line('Pozitie: '||self.coord_x||' '||self.coord_y);
   END afiseaza_pozitie;

    map member FUNCTION suprafata_forma RETURN NUMBER IS
    begin
        return self.suprafata;
    end suprafata_forma;

     not final member procedure seteaza_suprafata(suprafata number) IS
     begin
     self.suprafata := suprafata;
     end seteaza_suprafata;

      member procedure seteaza_pozitia(x number, y number) is
      begin
      self.coord_x := x;
      self.coord_y := y;
      end seteaza_pozitia;

      CONSTRUCTOR FUNCTION  forma(nume varchar2, culoare varchar2)
    RETURN SELF AS RESULT
  AS
  BEGIN
    SELF.nume := nume;
    SELF.culoare := culoare;
    SELF.suprafata := 1;
    SELF.coord_x := 0;
    SELF.coord_y := 0;
    RETURN;
  END;
END;
/

