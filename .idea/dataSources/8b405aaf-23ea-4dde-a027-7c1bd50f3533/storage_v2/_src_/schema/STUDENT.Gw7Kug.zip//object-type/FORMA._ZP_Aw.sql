CREATE TYPE forma AS OBJECT
(nume varchar2(30),
 culoare varchar2(15),
 suprafata number,
 coord_x number,
 coord_y number,
 member procedure afiseaza_nume,
 member procedure afiseaza_culoare,
 member procedure afiseaza_pozitie,
 not final member procedure afiseaza_tip,
 map member FUNCTION suprafata_forma RETURN NUMBER, 
 member procedure seteaza_suprafata(suprafata number),
 member procedure seteaza_pozitia(x number, y number),
 CONSTRUCTOR FUNCTION forma(nume varchar2, culoare varchar2)
    RETURN SELF AS RESULT
) NOT FINAL;
/

