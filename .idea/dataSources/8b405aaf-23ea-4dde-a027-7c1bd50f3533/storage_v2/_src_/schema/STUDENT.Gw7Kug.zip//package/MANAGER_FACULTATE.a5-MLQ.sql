CREATE PACKAGE manager_facultate IS

      CURSOR tabel_studenti(numar_matricol studenti.nr_matricol%type) IS 
          SELECT id, nr_matricol, nume, prenume FROM studenti ;
      CURSOR fisa_matricola(v_id_student studenti.id%type) IS
          Select titlu_curs, valoare from note join cursuri on note.id_curs =cursuri.id 
                  where note.id_student = v_id_student;

       CURSOR prieteni_studenti(v_id_student studenti.id%type) IS
          SELECT nume,prenume  from studenti join prieteni on studenti.id=prieteni.id_student2
                  where id_student1=v_id_student;


        PROCEDURE informatii_student (numar_matricol studenti.nr_matricol%type);
        PROCEDURE stergere_student ( p_id_student studenti.id%type);
END manager_facultate;
/

