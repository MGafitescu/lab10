CREATE PROCEDURE prieteni_medii as

    CURSOR lista_prieteni  IS
        SELECT ID_STUDENT1,id_student2 FROM prieteni;
   v_linie lista_prieteni%ROWTYPE;
   v_medie1 NUMBER;
   v_medie2 NUMBER;
   v_numar NUMBER := 0;

BEGIN
    FOR v_linie IN lista_prieteni LOOP 
        select trunc(avg(valoare)) into v_medie1 from note where id_student=v_linie.id_student1 group by note.id_student;
        select trunc(avg(valoare)) into v_medie2 from note where id_student=v_linie.id_student2 group by note.id_student;
        IF (v_medie1 = v_medie2)
        THEN 
        v_numar := v_numar +1
         DBMS_OUTPUT.PUT_LINE(v_linie.id_student1||'-'||v_linie.id_student2);
        END IF; 
    END LOOP;
DBMS_OUTPUT.PUT_LINE(V_numar);
END;
/

