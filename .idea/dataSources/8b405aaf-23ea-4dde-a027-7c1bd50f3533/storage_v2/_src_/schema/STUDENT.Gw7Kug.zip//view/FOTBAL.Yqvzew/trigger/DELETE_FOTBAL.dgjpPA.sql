-- Cannot generate trigger DELETE_FOTBAL: the table is unknown
/

