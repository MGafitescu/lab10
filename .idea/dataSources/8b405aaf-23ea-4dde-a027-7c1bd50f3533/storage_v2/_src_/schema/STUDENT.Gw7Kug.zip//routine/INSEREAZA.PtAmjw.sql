CREATE PROCEDURE insereaza AS
v_nume erasmus.nume%type;
v_prenume erasmus.prenume%type;
v_nr_matricol erasmus.nr_matricol%type;
v_id_tara erasmus.id_tara%type;
v_id NUMBER;
v_exista NUMBER;
student_existent EXCEPTION;
PRAGMA EXCEPTION_INIT(student_existent, -20001);
BEGIN
FOR v_contor IN 1..100 LOOP
       v_id := TRUNC(DBMS_RANDOM.VALUE(1,1022)); 
       SELECT nume, prenume, nr_matricol into v_nume,v_prenume,v_nr_matricol from studenti where id=v_id;
       v_id_tara :=trunc(dbms_random.value(1,21));
       select count(*) into v_exista from erasmus where nr_matricol=v_nr_matricol;
      -- if v_exista < 1 then
       insert into erasmus values(v_nr_matricol,v_nume,v_prenume,v_id_tara);
       DBMS_OUTPUT.PUT_LINE('Am inserat studentul '||v_nr_matricol||' '||v_nume||' '||v_prenume);
      -- else
       --raise student_existent;
       --end if;
   END LOOP;
END insereaza;
/

